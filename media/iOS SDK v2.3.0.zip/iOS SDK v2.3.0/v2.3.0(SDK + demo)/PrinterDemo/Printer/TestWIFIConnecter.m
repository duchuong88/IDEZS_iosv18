//
//  TestWIFIConnecter.m
//  Printer
//
//  Created by Apple Mac mini intel on 2023/9/5.
//  Copyright © 2023 Admin. All rights reserved.
//

#import "TestWIFIConnecter.h"

@implementation TestWIFIConnecter

- (void)dealloc {
    NSLog(@"object release...");
}

@end
