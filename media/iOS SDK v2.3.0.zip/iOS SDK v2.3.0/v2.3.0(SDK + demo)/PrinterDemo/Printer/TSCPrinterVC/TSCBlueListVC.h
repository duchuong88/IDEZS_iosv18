//
//  TSCBlueListVC.h
//  Printer
//

#import <UIKit/UIKit.h>

@interface TSCBlueListVC : UIViewController

@end

