//
//  TestWIFIConnecter.h
//  Printer
//
//  Created by Apple Mac mini intel on 2023/9/5.
//  Copyright © 2023 Admin. All rights reserved.
//

#import "WIFIConnecter.h"

NS_ASSUME_NONNULL_BEGIN

@interface TestWIFIConnecter : WIFIConnecter

@end

NS_ASSUME_NONNULL_END
