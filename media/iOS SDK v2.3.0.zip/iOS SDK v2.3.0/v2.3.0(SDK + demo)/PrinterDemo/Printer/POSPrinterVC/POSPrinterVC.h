//
//  POSPrinterVC.h
//  Printer
//

#import <UIKit/UIKit.h>

@interface POSPrinterVC : UIViewController


@end

