//
//  WIFIViewController.h
//  Printer
//
//  Created by Apple Mac mini intel on 2023/9/4.
//  Copyright © 2023 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WIFIViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
